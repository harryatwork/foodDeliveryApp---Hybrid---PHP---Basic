<?php include('header.php'); ?>

            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card" id="profile-main">

                                <div class="card-content">
                                    <h3>Add Product</h3>
                                    <div role="tabpanel">
                             <?php 
								$email = $_SESSION['email'];
								$sqlnesu = "SELECT * FROM vendors WHERE email = '$email' ";
								$resultnesu = $conn->query($sqlnesu);
								if ($resultnesu->num_rows > 0) {   
								while($rownesu = $resultnesu->fetch_assoc()) {  
									$v_id = $rownesu["id"]; 
							?>

                                        <div class="tab-content">

                                            <div role="tabpanel" class="tab-pane active" id="profile11">
											<!--
                                                <p>Morbi mattis ullamcorper velit. Etiam rhoncus. Phasellus leo dolor, tempus non, auctor et, hendrerit quis, nisi. Cras id dui. Curabitur turpis..Morbi mattis ullamcorper velit. Etiam rhoncus. Phasellus leo
                                                    dolor, tempus non, auctor et, hendrerit quis, nisi. Cras id dui. Curabitur turpis..</p>
											-->
                                                <div class="row">
                                                    <div class="col-sm-12">
                                                        <div class="p-15">
                                                            <div class="row m-l-5">
                                                            
															<form action="addproduct" method="post" enctype="multipart/form-data">
															
															<div class="form-group label-floating">
																<label class="control-label">
																	Type Product Name
																	<small>*</small>
																</label>
																<input class="form-control" name="name" type="text" required="true" />
															</div>

															<div class="form-group label-floating">
																<label class="control-label">
																	Choose Category
																	<small>*</small>
																</label>
																<select class="form-control" name="category" required="true">
																	<?php 
																			$sql5 = "SELECT * FROM cat";
																			$result5 = $conn->query($sql5);
																			if ($result5->num_rows > 0) {                               
																			while($row5 = $result5->fetch_assoc()) { 
																				$category = $row5["cat"];
																	?>
																	<option value="<?php echo $category; ?>" ><?php echo $category; ?></option>
																	<?php } } else { } ?>
																</select>
															</div>
															
															<div class="form-group label-floating">
																<label class="control-label">
																	Choose Sub Category
																	<small>*</small>
																</label>
																<select class="form-control" name="subcategory" required="true">
																	<?php 
																			$sql5 = "SELECT * FROM subcat";
																			$result5 = $conn->query($sql5);
																			if ($result5->num_rows > 0) {                               
																			while($row5 = $result5->fetch_assoc()) { 
																				$subcategory = $row5["subcat"];

																	?>
																	<option value="<?php echo $subcategory; ?>" ><?php echo $subcategory; ?></option>
																	<?php } } else { } ?>
																</select>
															</div>
															
															
															<div class="form-group label-floating">
																<label class="control-label">
																	Type Specification No:1
																	<small>*</small>
																</label>
																<input class="form-control" name="spec_1" type="text" required="true" />
															</div>
															
															<div class="form-group label-floating">
																<label class="control-label">
																	Type Specification No:2
																	<small>*</small>
																</label>
																<input class="form-control" name="spec_2" type="text" required="true" />
															</div>
															
															<div class="form-group label-floating">
																<label class="control-label">
																	Type Specification No:3
																	<small>*</small>
																</label>
																<input class="form-control" name="spec_3" type="text" required="true" />
															</div>
															
															
															<div class="form-group label-floating">
																<label class="control-label">
																	Type SKU Code
																	<small>(optional)</small>
																</label>
																<input class="form-control" name="sku" type="text" />
															</div>
															
															
															
															<div class="form-group label-floating">
																<label class="control-label">
																	Type Available Product Stock Quantity
																	<small>*</small>
																</label>
																<input class="form-control" name="stock" type="number" required="true" />
															</div>
															
															<div class="form-group label-floating">
																<label class="control-label">
																	Type Unit Product Price
																	<small>*</small>
																</label>
																<input class="form-control" name="price" type="number" required="true" />
															</div>
															<div class="form-group label-floating">
																<label class="control-label">
																	Type Discount Price (If No Discount Type Actual Price)
																	<small>*</small>
																</label>
																<input class="form-control" name="d_price" type="number" required="true"/>
															</div>
															<div class="form-group label-floating">
																<label class="control-label">
																	
																	<small></small>
																</label>
																<select name="color_1" class="form-control" >
																	<option value="">Is the Product Available in Red</option>
																	<option value="Yes">Yes</option>
																</select>
															</div>
															
															<div class="form-group label-floating">
																<label class="control-label">
																	
																	<small></small>
																</label>
																<select name="color_2" class="form-control" >
																	<option value="">Is the Product Available in Black</option>
																	<option value="Yes">Yes</option>
																</select>
															</div>
															
															<div class="form-group label-floating">
																<label class="control-label">
																	
																	<small></small>
																</label>
																<select name="color_3" class="form-control" >
																	<option value="">Is the Product Available in Navy Blue</option>
																	<option value="Yes">Yes</option>
																</select>
															</div>
															
															<div class="form-group label-floating">
																<label class="control-label">
																	
																	<small></small>
																</label>
																<select name="color_4" class="form-control" >
																	<option value="">Is the Product Available in Green</option>
																	<option value="Yes">Yes</option>
																</select>
															</div>
															
															<div class="form-group label-floating">
																<label class="control-label">
																	
																	<small></small>
																</label>
																<select name="color_5" class="form-control" >
																	<option value="">Is the Product Available in Blue</option>
																	<option value="Yes">Yes</option>
																</select>
															</div>
															
															
															<div class="form-group label-floating">
																<label class="control-label">
																	Product Description
																	<small>*</small>
																</label>
																<textarea class="form-control" name="description" required="true" type="number"></textarea>
															</div>
															
															
																<label class="control-label">
																	Choose a Picture
																	<small>*</small>
																</label>
																<input  name="file_1" type="file" required="true" />
																
																<label class="control-label">
																	Choose a Picture
																	<small>(optional)</small>
																</label>
																<input  name="file_2" type="file"  />
																
																<label class="control-label">
																	Choose a Picture
																	<small>(optional)</small>
																</label>
																<input  name="file_3" type="file"  />
																
																<label class="control-label">
																	Choose a Picture
																	<small>(optional)</small>
																</label>
																<input  name="file_4" type="file"  />
																
																<label class="control-label">
																	Choose a Picture
																	<small>(optional)</small>
																</label>
																<input  name="file_5" type="file"  />
															
															<hr>
															<input type="hidden" name="v_id" value="<?php echo $v_id; ?>" />
															<hr>
															<br>
															<br><br>
																<button class="btn btn-success">Add Product</button>
															</form>
															 
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
												<hr>
								<?php } } else { } ?>
												
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
					

					
					
                </div>
            </div>

			
			<?php include('footer.php'); ?>