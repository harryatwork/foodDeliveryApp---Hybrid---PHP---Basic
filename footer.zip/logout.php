<?php
	//24 2 2015
	session_start();
	session_destroy();
    header("location:../index.php")

?>