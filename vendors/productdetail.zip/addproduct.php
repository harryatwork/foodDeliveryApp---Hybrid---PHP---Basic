<?php 
 include('../db.php'); 
  include('dashboard.php'); 


$name = $_POST['name'];
$category = $_POST['category'];
$subcategory = $_POST['subcategory'];

$spec_1 = $_POST['spec_1'];
$spec_2 = $_POST['spec_2'];
$spec_3 = $_POST['spec_3'];

$color_1 = $_POST['color_1'];
$color_2 = $_POST['color_2'];
$color_3 = $_POST['color_3'];
$color_4 = $_POST['color_4'];
$color_5 = $_POST['color_5'];

$sku = $_POST['sku'];

$stock = $_POST['stock'];
$price = $_POST['price'];
$d_price = $_POST['d_price'];
$description = $_POST['description'];

$v_id = $_POST['v_id'];

$status = 'Non Active';




$date = date_default_timezone_set('Asia/Kolkata');
$date = date('M-d,Y H:i:s');
$date2 = date('M-d,Y');

$file_1=($_FILES['file_1']['name']);
$file_2=($_FILES['file_2']['name']);
$file_3=($_FILES['file_3']['name']);
$file_4=($_FILES['file_4']['name']);
$file_5=($_FILES['file_5']['name']);

$conn = new mysqli ($servername, $dbusername, $dbpassword, $dbname);
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO products (name, status, v_id, cat, subcat,  spec_1, spec_2, spec_3, color_1, color_2, color_3, color_4, color_5, sku, stock, price, d_price, pic_1, pic_2, pic_3, pic_4, pic_5, description, date)
VALUES ('$name', '$status', '$v_id', '$category', '$subcategory', '$spec_1', '$spec_2', '$spec_3', '$color_1', '$color_2', '$color_3', '$color_4', '$color_5', '$sku', '$stock', '$price', '$d_price', '$file_1', '$file_2', '$file_3', '$file_4', '$file_5', '$description', '$date2')";
 
if ($conn->query($sql) === TRUE) {
$target_dir = "../images/products/";


$target_file1 = $target_dir . basename($_FILES["file_1"]["name"]);
$uploadOk1 = 1;
$imageFileType1 = strtolower(pathinfo($target_file1,PATHINFO_EXTENSION));
if ($uploadOk1 == 0) {
    echo "ERROR";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["file_1"]["tmp_name"], $target_file1)) {
	

	
$target_file2 = $target_dir . basename($_FILES["file_2"]["name"]);
$uploadOk2 = 1;
$imageFileType2 = strtolower(pathinfo($target_file2,PATHINFO_EXTENSION));
if ($uploadOk2 == 0) {
    echo "ERROR";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["file_2"]["tmp_name"], $target_file2)) {
	

	
$target_file3 = $target_dir . basename($_FILES["file_3"]["name"]);
$uploadOk3 = 1;
$imageFileType3 = strtolower(pathinfo($target_file3,PATHINFO_EXTENSION));
if ($uploadOk3 == 0) {
    echo "ERROR";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["file_3"]["tmp_name"], $target_file3)) {
	

	
$target_file4 = $target_dir . basename($_FILES["file_4"]["name"]);
$uploadOk4 = 1;
$imageFileType4 = strtolower(pathinfo($target_file4,PATHINFO_EXTENSION));
if ($uploadOk4 == 0) {
    echo "ERROR";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["file_4"]["tmp_name"], $target_file4)) {
	

	
$target_file5 = $target_dir . basename($_FILES["file_5"]["name"]);
$uploadOk5 = 1;
$imageFileType5 = strtolower(pathinfo($target_file5,PATHINFO_EXTENSION));
if ($uploadOk5 == 0) {
    echo "ERROR";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["file_5"]["tmp_name"], $target_file5)) {
	

	
	echo '<script language="javascript">';
		echo 'alert("Product has been Added successfully. Please wait while Admin Verifies it")';
		echo '</script>';
		echo '<a href="dashboard.php"></a>';
	
	

} else {
        echo '<script language="javascript">';
		echo 'alert("Product has been Added successfully. Please wait while Admin Verifies it")';
		echo '</script>';
		echo '<a href="dashboard.php"></a>';
    }
}
	
	

} else {
        echo '<script language="javascript">';
		echo 'alert("Product has been Added successfully. Please wait while Admin Verifies it")';
		echo '</script>';
		echo '<a href="dashboard.php"></a>';
    }
}
	
	

} else {
        echo '<script language="javascript">';
		echo 'alert("Product has been Added successfully. Please wait while Admin Verifies it")';
		echo '</script>';
		echo '<a href="dashboard.php"></a>';
    }
}
	
	

} else {
        echo '<script language="javascript">';
		echo 'alert("Product has been Added successfully. Please wait while Admin Verifies it")';
		echo '</script>';
		echo '<a href="dashboard.php"></a>';
    }
}	
	
	

} else {
        echo '<script language="javascript">';
		echo 'alert("Product has been Added successfully. Please wait while Admin Verifies it")';
		echo '</script>';
		echo '<a href="dashboard.php"></a>';
    }
}



}
else {
	echo "ERROR" . $sql . "<br>" . $conn->error;
}
$conn->close();

?>
